package com.example.oguzhanchat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.Timer;
import java.util.TimerTask;

public class Create_Acount extends AppCompatActivity {
    private EditText user_name,pass,c_pass;
    private Button create_ac;
    private ProgressBar prgbar;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create__acount);
        create_ac=(Button)findViewById(R.id.createacount);
        prgbar=(ProgressBar) findViewById(R.id.progressBar);

        create_ac.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                prgbar.setVisibility(View.VISIBLE);
                create_ac.setVisibility(View.GONE);
            }
        });
    }



}
