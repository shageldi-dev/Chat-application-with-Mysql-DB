package com.example.oguzhanchat;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ListView;

public class Chat extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chat);
        ListView listView=(ListView)findViewById(R.id.listwiev);
        for(int i=0;i<=10;i++)
        {

        }
    }
}
